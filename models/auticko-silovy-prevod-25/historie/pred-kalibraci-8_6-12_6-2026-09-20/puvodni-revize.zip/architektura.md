# Volba plně tištěného převodu

Stav19.9.2026: návrhové rozhodnutí pro nový samostatný prototyp. Číselné rozměry níže jsou vlastní výpočty; skutečné provedení a výsledky kontrol uvádí [README](README.md) a kontrolní JSON. Žádná vypočtená varianta nepředstavuje změřenou tažnou sílu.

## Co požaduje uživatel

- Větší praktický tah než u zasekávající se V2; lze změnit celé uspořádání, počet stupňů, výšku a půdorys.
- Všechny nové mechanické díly tištěné. Bez nově kupovaných os, ložisek, pouzder či mechanických spojovacích dílů.
- Výstupní záběr využívá celou pracovní šířku užšího ozubení i při dovoleném axiálním posuvu. Fyzické hlášení „půl zubu“ označovalo šířku, nikoli přesné měření.
- Kompletní tiskový ZIP i rozmístěné3MF obsahují všechny fyzické kopie, přesně4pojezdová kola. Žádné ruční násobení.
- Motor, elektronika a jejich ovládání navazují na stávající projekt; tento návrh firmware nemění.
- Výsledkem je revidovaná V3 **s předním zatáčením SG90**, nikoli samostatná pevná náprava. Použije se vlastněná originální páčka a její středový šroubek. Další nové mechanické díly mají být tištěné; starý požadavek V3 na M2 spoj a pásky se nepřebírá.

## Porovnání

Srovnání používá stejná kola Ø76, která navazují na V3. Původní pracovní výpočet s Ø80 měl světlosti o 2 mm vyšší; nejde o druhé provedení k tisku. Pro nové třístupňové kandidáty je modul1mm, úhel20° a přirážka každé osové vzdálenosti0,4mm. U vybraného25:1 již tabulka zahrnuje níže popsané prodloužení hlavy zubů; ostatní kandidáti mají standardní výšku hlavy1m. Původní dvoustupňový kandidát16:1 měl modul0,9 a přirážku0,2mm. Volba vyšší přirážky souvisí s novým součtem tištěných kluzných vůlí; není to požadavek na nulovou vůli zubů.

| Kandidát | Zuby jednotlivých stupňů | Velké hlavové průměry | Nejmenší světlost ozubení při stejných výškách os | Ideální moment osy / otáčky osy proti12:1 |
|---|---|---|---|---|
|16:1, dva stupně |18→72;18→72, m0,9 |66,6/66,6mm |4,7mm |1,333× /0,75× |
|**25:1, tři stupně** |**18→54;18→60;22→55, m1** |**56,4/62,4/57,4mm** |**6,8mm** |**2,083× /0,48×** |
|36:1, tři stupně |18→54;18→72;24→72, m1 |56/74/74mm |1mm |3× /0,333× |

U25:1 jsou osové vzdálenosti36,4/39,4/38,9mm, celkové rozpětí motor–zadní osa114,7mm. U36:1 jsou36,4/45,4/48,4mm, součet130,2mm. Zvednutí meziosy může pomoci světlosti mezikola, ale samotný poslední věnec na zadní oseØ74 zůstane pouze1mm nad ideální rovnou zemí při koleØ76. Větší pojezdová kola tuto mezeru zvýší, ale část přínosu tahu zase spotřebují a změní podvozek. Vyšší plošina nebo prostorové uspořádání jsou možné, nikoli zakázané zadáním.

**Volba25:1:** proti12:1 podstatně zvýší redukci, dovolí hrubší modul1 a22zubý poslední pastorek, přitom zachová6,8mm světlost převodů bez zvětšení jízdních kol. Třetí stupeň přidá tření a díly. Proti16:1 je ideální poměr momentů25/16; při zjednodušeném předpokladu stejných ostatních ztrát musí mít přidaný stupeň účinnost nad64%, aby sám tento ideální přínos nesmazal. Není to změřená účinnost ani záruka rozjezdu.

36:1 by proti25:1 přidalo44% ideálního momentu a snížilo rychlost přibližně o31%, za cenu větších věnců, nižší světlosti a vyššího namáhání výstupu. Neodmítáme ho kvůli zachování starého rámu; pro první plně tištěnou funkční revizi dáváme přednost rezervě vůči podlaze a lehkému chodu. Bez známého momentu/otáček motoru, požadované zátěže, minimální rychlosti a přilnavosti **nelze stanovit univerzálně nejsilnější použitelný převod**. Samotný převod lze zvyšovat libovolně za cenu rychlosti; jeho praktický přínos musí potvrdit zkouška.

Poslední pár25:1 je22→55 místo původně uvažovaného20→50. Při20→50 by60zubé kolo předchozího stupně zasahovalo do obálky průběžnéØ12 zadní osy:35,4−31,2−6=−1,8mm. U22→55 je nominální rezerva38,9−31,2−6=1,7mm. Zde je již započtené prodloužení hlavy 60zubého věnce na poloměr31,2mm. Příčný klínek a hlava nesmějí být v této rovině: výstupní náboj se prodlužuje na opačnou stranu a klínek je mimo sousední60z věnec. Tento detail kontroluje celý CAD, nikoli pouze rovnice soukolí.

## Kontakt zubů také při největší radiální vůli

Pouhá kontrola neprůniku neprokazuje nepřerušený přenos pohybu. Při standardní hlavě zubu1m a maximálním návrhovém oddálení středů vyšel teoretický kontaktní poměr tří stupňů 0,99930 / 1,00484 / 0,97996. U prvního a třetího je pod1, takže existuje interval bez kontaktu sousedních párů zubů. Proto se tato pracovní geometrie nepředává jako finální.

Exportovaný nový CAD používá malá kola18/22 s výškou hlavy **1,1m** a velká54/60/55 s **1,2m**. Výška paty zůstává1,25m, modul1, základní úhel20°, korekce posunutím profilu je nulová. Jde o prodloužení hlavy zubu, nikoli o změnu převodu, roztečí nebo zmenšení tiskových vůlí.

| Stupeň | Rozteč min / nominál / max | Nejnižší teoretický kontaktní poměr, při max rozteči | Nejmenší radiální mez špička–kořen, při min rozteči |
|---|---|---:|---:|
|18→54 |36,10 / 36,40 / 36,70 mm |1,21964 |0,15 mm |
|18→60 |39,10 / 39,40 / 39,70 mm |1,22799 |0,15 mm |
|22→55 |38,55 / 38,90 / 39,25 mm |1,20401 |0,10 mm |

Výpočet používá délku úseku záběru dělenou základní roztečí: `(sqrt(ra1²−rb1²) + sqrt(ra2²−rb2²) − a × sin(αw)) / (π × m × cos(20°))`, kde `cos(αw) = (rb1+rb2)/a`. Obecný vztah uvádí [KHK – kontaktní poměr](https://khkgears.us/media/2y2ndg1y/gear-solutions_khk_the-importance-of-contact-ratios.pdf); konkrétní rozměry a výsledky jsou vlastní výpočty.

Dělení výšek chrání malé zuby. **Měření skutečných CAD hran všech špiček** v [nezávislé kontrole](nezavisla-kontrola.json) dalo minimální tětivu0,558857mm u obou18zubých kol,0,591058mm u22zubého,0,594279mm u54zubého,0,603680mm u60zubého a0,595977mm u55zubého. Není to jen výsledek vzorce pro ideální evolventu. Jednotné prodloužení1,2m by špičku18zubého kola zúžilo asi na0,432mm. Ani uvedené širší hodnoty neprokazují únosnost či správné dráhy trysky0,4; náhled skutečných vrstev a fyzická zkouška zůstávají nutné.

Nové hlavové průměry velkých kol jsou přibližně56,4/62,4/57,4mm. Světlost vůči rovné podložce při koleØ76 je nominálně6,8mm a rezerva60zubého kola kØ12zadní ose1,7mm. Skutečné hrany aproximovaného profilu se liší pod0,002mm v poloměru; obálková kontrola zahrnuje ještě0,01mm navíc. Kontrola celých obálek a průchodů v rámu po prodloužení hlav prošla. Výpočet poměru kontaktu sám **nenahrazuje kontrolu kolizí špiček a kořenů v pohybu**: na finální geometrii proběhlo65 vzorků fáze všech tří párů při nominálních i nejmenších roztečích bez objemového průniku.

Použitý profil FreeCADu aproximuje evolventu Bézierovými křivkami a pod nimi obsahuje přechod k patě. Nezávislá kontrola proto načetla skutečné dolní koncové poloměry těchto hran: po omezení aktivního úseku na skutečně modelovanou evolventu zůstává při minimálních roztečích poměr přibližně1,67988 / 1,67988 / 1,85050. Při maximálních roztečích omezení výše uvedená minima1,21964 / 1,22799 / 1,20401 nesnižuje. Jde stále o geometrický výpočet aktivního úseku; exaktní konjugaci celé aproximované křivky, pevnost ani skutečný tisk tím neprohlašujeme za prokázané.

## Tři pracovní roviny a axiální podmínka

Výchozí rozmístění ozubení vY:

| Stupeň | Hnací ozubení | Hnané ozubení | Nominální společná šířka |
|---|---|---|---:|
|1 |Motor18z:14,5..19,5 |A54z:12..20 |5mm |
|2 |A18z:0..8 |B60z:−2..10 |8mm |
|3 |B22z:−16..−8 |Výstup55z:−18..−6 |8mm |

Druhý i třetí stupeň vystřeďují8mm pastorek do12mm kola. Podmínka plného překrytí je `abs(Ystřed_pastorek − Ystřed_věnec) ≤ 2mm` ve **všech** dovolených krajních polohách. Rozhoduje společný posuv obou součástí včetně klínku, čepů, pojistek a drážek; nelze kontrolovat každou vůli odděleně a zapomenout na jejich součet. Kontrola16 kombinací krajních poloh A±0,2 / B±0,2 / výstup±0,4 / motor0..+0,4mm prošla. Poslední záběr zachovává celých8mm s nejmenší boční rezervou1,4mm; první záběr může klesnout z5 na4,9mm. Zuby se v kontrolovaných polohách čely nedotýkají sousedního kotouče ani podpěry.

## Uložení a cesta momentu

- MezikolaA/B se otáčejí na stacionárních kruhových tištěných čepechØ8 podepřených na obou koncích. Ploška/klíč hlavy je mimo kluzné plochy. Dvě krátká vodicí pásma náboje a odlehčený střed omezují dlouhou třecí plochu.
- Zadní osaØ12 má kruhové pracovní úseky v rámu, Dkonce pod koly a samostatný příčný tištěný klínek spojující výstupní věnec s osou. Kruhový otvor věnce umožní navléknutí přes kruhová uložení. Pojistky mají určit polohu, ne stáhnout otočná čela.
- Motor má tištěný třmen a tištěné mechanické zajištění; nová sestava není závislá na nepotvrzených páscích nebo nových šroubech. Zadní elektrické kontakty musí zůstat přístupné.
- Prozatímní průměrové fit hodnoty8,2 proti8;12,2 proti12 a8,1 pro pevné čepy jsou návrhové. Kalibrace ověří tisk, nikoli údaj na obrazovce. Celé auto se kvůli otvorům nesmí plošně škálovat.
- Meziosové kolo má maximální modelový radiální posuv0,15mm:0,10mm v rotujícím náboji plus0,05mm v sedle pevného čepu. Dvě podpory jednoho čepu čistou translaci nezdvojnásobují. Druhý stupeň má proto vzdálenost39,10..39,70mm. Výstupní věnec má až0,20mm:0,10mm uložení osy plus0,10mm věnec/osa; příčný klínek bez měření nepovažujeme za bezvůlové vystředění. Třetí stupeň proto pokrývá38,55..39,25mm. Proti standardní rozteči zbývá při největším přiblížení jen0,10/0,05mm. Jde o geometrickou obálku, **nikoli potvrzenou výrobní rezervu**. Změna průměrů podle vzorku vyžaduje přepočet celého stohu a podle potřeby i osové vzdálenosti, nejen zvětšení otvoru.
- V modelu se součet radiálních vůlí kontroluje jako konzervativní posun středů. Nejde o výpočet pružných deformací, naklopení, drsnosti, tepla či opotřebení.

Tři vnější záběry otáčejí výstup **opačně než motor**, zatímco V2 se dvěma stupni ho otáčela stejně. Při fyzickém testu bude nutné ověřit směr jízdy; firmware zde zůstává zachovaný.

## Dvě hladká vodicí pásma místo dlouhého otvoru

U 30mm náboje mezikola je zvolen návrhový kompromis **dvou 5mm souvislých obvodových pásem Ø8,2 mm** na obou koncích. Prostředních 20 mm má odlehčení Ø9 mm. Jde o obyčejné válcové plochy, nikoli ostrá žebra nebo spirálu. Čep zůstává kruhový Ø8 mm a podepřený na obou stranách; menší kontaktní plocha není důvod ke slepému zmenšení jeho průměru.

| Délka každého pásu | Nominální promítnutá plocha dvou pásů, d = 8 mm | Vzdálenost středů pásů | Relativní průměrný tlak při stejné souměrné síle | Relativní tlak od stejného čistého klopného momentu |
|---|---:|---:|---:|---:|
| Původních 7 mm |112 mm² |23 mm |1,00 |1,00 |
| **Zvolených 5 mm** |**80 mm²** |**25 mm** |**1,40** |**1,288** |
| Uvažované 4 mm |64 mm² |26 mm |1,75 |1,548 |
| Uvažované 3 mm |48 mm² |27 mm |2,333 |1,988 |

Jde o srovnání podle promítnuté plochy a statické dvojice sil, nikoli výpočet skutečného kontaktního tlaku na nerovném tisku. Obecný vztah průměrného tlaku je `p = F / (d × L)`; pro dvojici stejnoměrně zatížených pásů se jejich délky sčítají. Materiálové limity průmyslových kluzných ložisek nejsou limity tištěného PLA. Viz [igus – výpočet tlaku v kluzném ložisku](https://toolbox.igus.com/motion-plastics-blog/how-to-calculate-surface-pressure-for-plain-bearings/).

Kratší pásy snižují délku citlivou na nerovnost dlouhého otvoru; zvětšují ovšem tlak a citlivost na hranové zatížení. Volba 5 mm zachovává dostatečně široké, dobře rozpoznatelné plochy a větší rezervu proti 3–4mm variantám. **Nosnost, tření a životnost nebyly změřené**; neznáme zatížení, drsnost ani konečný tiskový fit.

Obě pásma nadále sahají k čelům náboje vzdáleným 30 mm. Průměrová vůle 0,2 mm připouští v ideálním tuhém modelu orientační horní úhlovou vůli `0,2 / 30 rad ≈ 0,382°`; nejde o předpis přípustného náklonu při provozu. Zkrácení pásů samo tuto vůli nesnižuje. Reálné naklopení, deformace čepu a otlačení mohou ovlivnit záběr a nejsou pokryté pouhou kontrolou rovnoběžného posuvu středů.

**Odlehčený střed nesmí po opotřebení převzít vedení.** Jeho radiální vůle vůči Ø8 činí 0,5 mm, proti vodicím pásům o 0,4 mm více; to překračuje zbývající nominální rezervy osové vzdálenosti 0,10/0,05 mm. Opotřebení se samo nevymezí. Při novém viditelném kývání, proměnlivém záběru, poškozeném či oválném pásu sestavu rozebrat a podle nálezu vyměnit čep nebo mezikolo. Počet hodin ani přesná servisní mez v mm nejsou bez fyzických zkoušek určené. Kluzné plochy nelepit. Přidané výměnné pouzdro by zavedlo další vůlové rozhraní; v této revizi se proto nepřidává.

## Integrace řízení původní V3

Přímé přenesení původního úzkého předku do rámu širokého 112 mm by při zatáčení způsobilo kolizi kol. Dokončená revize proto používá kingpiny X190 / Y±72 mm, ramena délky 20 mm, spojnici 144 mm a osu serva X220 mm. Při přímé poloze mají kola středy X186,3 / Y±87 mm a vnější boky Y±93 mm. Rám má délku236mm, přední příčník šířku160mm; plošina zachovává užitnou plochu 170 × 60 mm. Jde o nové konstrukční rozměry, nikoli uživatelova měření.

Obě kola se natáčejí stejným úhlem v rovnoběžníku. Není to Ackermannovo řízení; při zatáčení je nutné počítat se smýkáním kol. Návrhový pracovní rozsah je ±25°, mechanické dorazy ±27°. Analytické uzavření táhla při poloměru originální páčky 15 mm a délce servotáhla 72,1734 mm dává přibližně +33,51° / −35,10° serva pro pracovní krajní polohy; neprokazuje momentovou rezervu konkrétního SG90. CAD kontrola celé sestavy prošla ve21polohách včetně pracovních i dorazových; samostatně byly ověřené krajní axiální posuvy předních i zadních kol. Zachycení mechanickými dorazy je prokázané průnikem příslušných ploch při±27,5°. Nejde o pokyn takto elektricky přetáčet servo.

Originální páčka zůstává přímo na originálním drážkování a drží ji původní středový šroubek. Nový tištěný adaptér má zachytit rameno páčky a poskytnout vlastní větší kloub; nenahrazuje vnitřní drážkování ani nevyžaduje neznámý M2 šroub. Potvrzených 15 mm označuje vzdálenost osy serva ke krajnímu malému otvoru, nikoli šířku, tloušťku nebo výšku páčky. Fit navrženého adaptéru a uložení serva musí potvrdit fyzická zkouška. Elektronika serva se nemění ani nezapojuje.

## Hranice důkazů

Vstupem jsou uživatelem zadané rozměry motoruØ22,5×26mm, délka hřídelky6mm a dříve nasazený otvor2,2mm. Nejde o katalogový moment motoru, přesný průměr hřídele ani změřenou únosnost spoje. Nový pastorek je jiný díl a vyžaduje nový fit test. Krátký stolní test starého motorového zapojení neprokazuje nový mechanický převod.

Nominální platné těleso a uzavřená STL síť neprokazují účinnost ani vytištěnou toleranci. Všechny nové kluzné díly, pojistky, klínky a motorový třmen vyžadují postupnou fyzickou zkoušku. Nesmí se lepit pracovní ložiskové plochy ani ozubení. Fyzické výsledky se doplní podle skutečného hlášení.

Vzorce pro evolventní rozměry a vztah osové vzdálenosti k vůli: [KHK – rozměry ozubení](https://khkgears.net/new/gear_knowledge/gear_technical_reference/calculation_gear_dimensions.html), [KHK – vůle ozubení](https://khkgears.net/new/gear_knowledge/gear_technical_reference/gear_backlash.html). Konkrétní varianty a rozhodnutí výše jsou vlastní návrh, nikoli doporučení výrobce pro tuto tištěnou sestavu.

## Další uživatelské zkušenosti a předávací kontrola

Jiří hlásí výrazný odpor také na „tyčkách, které drží hřídele“ a navrhuje zúžení při zachování pevnosti. Neupřesnil, zda jde o průměr čepu, délku kluzného otvoru nebo podpěru. Nejde o rozměrové měření ani zadání zeslabit všechny osy. Kompromis návrhu: pevné čepy podepřené z obou stran, kratší skutečně vodicí pásma, odlehčený střed otvoru a kalibrace vůle; zadní torzní osa zůstává silnější. Menší kontaktní plocha sama nezaručuje menší tření. Nutná bude samostatná zkouška každé osy a poté jednotlivých záběrů bez motoru.

Jiří dále upřesnil, že v dřívější reálně vytištěné sadě chybělo kromě čtvrtého kola také druhé provedení „podložky na kolo a na převodovku“ a další díly. Přesný typ souboru ani způsob importu nejsou potvrzené. Existující ZIP se správným počtem kusů nevyvrací nekompletní skutečný výtisk. Jde o problém předání a čitelnosti kusovníku, nikoli prokázanou chybu uživatele.

Nová kontrola proto porovnává **montážní instance každého fyzického dílu → kusovník → jednotlivé kopie v ZIP → objekty ve všech3MF**. Ověřuje obě strany každého uložení včetně všech rozpěrek, pouzder, podložek, zámků a pojistek. Návod má uvést jednoznačné polohy a počty; rozložený pohled slouží k montáži, očíslovaná3MF k tisku všech kopií bez ručního duplikování.
