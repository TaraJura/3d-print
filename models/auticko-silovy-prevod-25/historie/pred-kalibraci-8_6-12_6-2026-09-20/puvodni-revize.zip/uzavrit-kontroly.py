#!/usr/bin/env python3
"""Uzavře hlavní kontrolní záznam a odvodí ZIP z instancí. Neprovádí CAD ani hardware."""
from pathlib import Path
from collections import Counter
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
def read(n):return json.loads((ROOT/n).read_text())
r=read('kontrola-modelu.json');s=read('kontrola-rizeni.json');v=read('kontrola-vuli.json');p=read('kontrola-parametru.json');k=read('kinematika.json');g=read('kontrola-gui.json')
assert g['gui_validation']['saved_and_reopened']
assert all(a['source_hashes']==r['source_hashes'] for a in (s,g,v,p))
assert r.get('gear_validation_pass') and s.get('steering_validation_pass') and v.get('passed') and p.get('passed')
assert not r['assembly_collisions'] and not s['motion']['collisions']
assert r['source_hashes']=={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in r['source_hashes']}
for key in ('motion','mechanical_stops','parametric_checks','tread_checks','ground_clearance_mm','world_wheel_bounds_mm'):r[key]=s[key]
r['gui_validation']=g['gui_validation'];r['final_print_group']=g['final_print_group']
r['steering_validation_pass']=True;r['wheel_axial_clearance_checks']=v;r['drivetrain_parameter_checks']=p;r['kinematics']=k
r['guide_bands']={'journal_diameter_mm':8,'running_bore_mm':8.2,'two_contact_lengths_mm':[5,5],'relieved_middle_diameter_mm':9,'relieved_middle_length_mm':20,'limit':'Změna plochy nezaručuje snížení tření. Nosnost, souosost, tilt a ohyb fyzicky neověřeny; při změně otvorů znovu vyhodnotit součet radiálních vůlí a osové vzdálenosti.'}
r['validation_pass']=True;r['status']='Geometricky ověřený CAD prototyp25:1+SG90; fyzický fit páčky/serva, tisk, pevnost a jízda neověřeny.'
r['validation_scope']={'static_assembly':True,'gear_motion_nominal_and_minimum_centres':True,'contact_ratio_at_maximum_centres':True,'actual_tip_edges':True,'steering_motion_and_wheel_rotation_envelopes':True,'separate_axial_extremes':True,'parametric_recompute_restore':True,'physical_test':False}
instances=r['assembly_instances'];counts=Counter(i['part'] for i in instances)
assert counts==Counter({n:a['copies'] for n,a in r['parts'].items()})
assert sum(counts.values())==len(instances)==r['total_print_count']
counter=Counter();entries=[]
with zipfile.ZipFile(ROOT/'tiskovy-balicek.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for instance in instances:
        key=instance['part'];counter[key]+=1;name=f'{key}__{counter[key]:02d}.stl';source=ROOT/instance['stl'];content=source.read_bytes()
        assert hashlib.sha256(content).hexdigest()==r['parts'][key]['sha256']
        zi=zipfile.ZipInfo(name,(2026,9,19,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,content)
        entries.append({'assembly_instance':instance['name'],'part':key,'archive_entry':name,'sha256':hashlib.sha256(content).hexdigest()})
    z.writestr('KUSOVNIK.json',json.dumps({'total':len(entries),'part_counts':dict(counts),'instances':entries,'source_hashes':r['source_hashes']},ensure_ascii=False,indent=2)+'\n')
r['print_bundle']={'file':'tiskovy-balicek.zip','total_stl_copies':len(entries),'counts_derived_from_actual_assembly_instances':True,'sha256':hashlib.sha256((ROOT/'tiskovy-balicek.zip').read_bytes()).hexdigest(),'entries':entries}
(ROOT/'kontrola-modelu.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'validation_pass':True,'part_types':len(counts),'physical_print_copies':len(instances),'zip':str(ROOT/'tiskovy-balicek.zip')},ensure_ascii=False))
