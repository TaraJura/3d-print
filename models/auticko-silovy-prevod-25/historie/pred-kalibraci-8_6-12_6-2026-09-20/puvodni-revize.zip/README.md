# Revidovaná V3: převod 25:1 a přední řízení SG90

**Hotový geometricky ověřený CAD prototyp: převod 25:1, přední řízení SG90 a 66 tištěných dílů.** Fyzický fit a jízda nové konstrukce zatím nejsou ověřené; před celou sadou vyhodnoť již zahájenou kalibraci. Nové mechanické díly se s předchozími verzemi nekombinují; využívá se tentýž motor, stávající elektronika a vlastněné servo SG90 s originální jednoramennou páčkou a středovým šroubkem. Původní V2/V3 i firmware jsou zachované.

Model vzniká po uživatelsky hlášeném zasekáváníV2, omezeném využití šířky posledního ozubeného záběru a chybějících kusech v reálně vytištěné sadě. Příčina původního odporu není prokázaná. [Rozbor původní konstrukce](../auticko-s-prevodovkou/revize-prevodovky.md) odděluje fyzická hlášení od CAD výpočtů; [volba nové architektury](architektura.md) porovnává16:1,25:1 a36:1.

## Soubory a prohlížení

- [Editovatelná sestava FreeCAD](auticko-silovy-prevod-25.FCStd).
- [Kompletní ZIP — 66 samostatných STL kopií](tiskovy-balicek.zip). Každý soubor vytisknout jednou; počty se už nenásobí. Neimportovat současně ZIP a rozložené 3MF.
- **Rozložené podložky Kobra X:** [01 — 26 kusů včetně všech čtyř kol](rozlozeni/auticko-25-podlozka-01.3mf), [02 — 27 kusů včetně rámu](rozlozeni/auticko-25-podlozka-02.3mf), [03 — 13 kusů včetně plošiny](rozlozeni/auticko-25-podlozka-03.3mf). Otevřít každou jako samostatnou podložku, každou vytisknout jednou; jde o alternativu k ZIPu. [Postup importu a očíslované náhledy](rozlozeni/README.md).
- Skutečné CAD náhledy: [rovně](rovne.png), [doleva](doleva.png), [doprava](doprava.png), [odkrytý mechanismus](mechanismus.png), [všechny rozložené díly](rozlozena-sestava.png). Barvy pouze rozlišují součásti; neurčují filament nebo kovový materiál.
- [Montážní návod](montaz.md), [architektura a výpočty](architektura.md), [nezávislá kontrola](nezavisla-kontrola.json).
- [Generátor](auticko-silovy-prevod-25.FCMacro) používá vedle sebe tři moduly: [geometrie řízení](rizeni-geometrie.py), [uchycení serva](servo-uchyceni.py), [sestavení řízení](rizeni-sestava.py). Pro regeneraci musí zůstat všechny čtyři soubory spolu. Samotný uložený FCStd obsahuje standardní editovatelné objekty a tabulky; k běžnému otevření nepotřebuje vlastní Python třídu.

Změna rozměru v tabulce může přepočítat navázané tvary; obrys zubů při změně modulu, počtu zubů nebo jejich profilu vyžaduje regeneraci makrem. Změny provozních vůlí se znovu ověřují proti celému stohu, nikoli jen podle platného jednotlivého tělesa. Kalibrační podložka je samostatná, hlavní makro ji nepřepisuje.

## Co nový návrh řeší

- Tři stupně18→54,18→60,22→55 dávají25:1, modul1mm. Prodloužené hlavy zubů se kontrolují i při největším oddálení os; kontrola pouhého neprůniku nestačí. Proti12:1 jde ideálně o2,083× větší moment při48% otáček, před ztrátami. Skutečnou sílu, rozjezd ani nosnost nelze bez zkoušky zaručit.
- Výstupní8mm pastorek je vystředěný do12mm věnce. Kontrola zahrnuje oba krajní axiální posuvy současně, aby celých8mm zůstalo v záběru.
- Mezikola mají pevné kruhové čepy podepřené z obou stran. Dvě souvislá 5mm vodicí pásma Ø8,2 a 20mm odlehčený střed Ø9 v 30mm náboji mají omezit citlivost na nepřesnost dlouhého tištěného otvoru. Menší plocha sama není důkazem menšího tření.
- Zadní osa má silnější kruhové pracovní úseky a oddělené spoje pro moment. Pojistky určují polohu; nestahují ozubená čela proti rámu.
- Nové uchycení motoru i mechanické zámky jsou tištěné. Návrh nepředpokládá nákup dalších os, ložisek, šroubů nebo pásků.
- Přední zatáčení navazuje na původní V3, ale používá nový širší předek a tištěné uchycení serva i originální páčky. Nepřebírá požadavek na nepotvrzené M2 šrouby, matice a stahovací pásky. Uživatel potvrdil účinný poloměr páčky 15 mm; ostatní rozměry páčky nejsou fyzicky ověřené.
- Všechna čtyři kola mají Ø76 × 12 mm se skutečným dezénem, plošina zachovává užitnou plochu 170 × 60 mm. Elektrické zapojení a ovládání serva bude samostatná etapa.
- Kompletní tiskový ZIP i tři 3MF vycházejí ze všech montážních instancí včetně čtyř kol a drobných opakovaných dílů. Složka jednotlivých typů STL sama není kompletní sadou k importu.

## Kalibrace před celou sadou

Připravený je [samostatný kalibrační balíček](kalibrace/README.md). **Jiří potvrdil zahájení jeho tisku; výsledky fitu zatím nemáme. Předané soubory jsou zmrazené.** Vzorky rozlišují otvor ve svislé a vodorovné orientaci, Ø8/12 kluzné součásti a Ø4 příčný klíček. Vyber skutečně lehce pohyblivý fit; nominální rozměr vCAD není změřený výtisk.

Kruhové čepy se tisknou naležato a potřebují podpory spodního oblouku. Po jejich odstranění nesmí na pracovní ploše zůstat výstupky. Zvolená orientace, očištění, materiál a nastavení otvorů musí odpovídat skutečným dílům. Kalibrační čep je krátký; souosost obou podpor a lehký chod konečné osy se ověří až při montáži.

## Aktuální uživatelský záměr ve sliceru

Jiří uvedl, že změnil běžnou výšku vrstvy z **0,20 na 0,08 mm** a horní povrch chce ponechat na standardním **Monotonic line**. Jde o jeho hlášení nastavení, nikoli o námi přečtené živé UI, osobní preset nebo hotový G-code. Potvrzení spuštění či dokončení tisku nové revize z něj neplyne.

Pokud toto nastavení ponechá, kalibrační vzorky i finální mechanické díly musí použít stejnou 0,08mm vrstvu a stejné ostatní nastavení. **První vrstva se tím automaticky nemění.** V místním systémovém profilu Kobra X 0,4 byl ověřen rozsah **0,08–0,28 mm**; Standard uvádí běžnou i první vrstvu **0,20 mm** a horní vzor `monotonicline`. Dokládá to [read-only záznam profilu](rozlozeni/profil-podlozky.json), nikoli kontrola neuloženého okna sliceru. Geometry-only 3MF obsahují pouze geometrii a rozmístění: výšku vrstvy, vzor povrchu, průtok, teploty ani osobní presety nepřepisují.

Nižší vrstva může zjemnit odstupňování oblých ploch ve směru Z; sama neopravuje XY průměry otvorů, tvar zubů, nesouosost ani neprokazuje nižší tření. Přepnutí mezi Rectilinear, Monotonic line a Archimedean chords není doložená oprava mechaniky; změna vzoru není součástí tohoto návrhu.

## Tiskové orientace a podpory

Orientace se ukládají do STL a zachovají v rozmístěných 3MF. Automatické otočení v nástroji Arrange může změnit povrchy, které se opírají o podpory; samotná kalibrace jiné orientace pak nemusí platit.

| Skupina | Orientace a co zkontrolovat ve skutečných vrstvách |
|---|---|
| Kola, výstupní kolo, motorový pastorek | Plochým čelem na podložku; u dezénu zkontrolovat drobné převisy a skutečné vyplnění špiček zubů |
| Dvojkola A/B | Velké ozubené čelo leží na podložce. Vyvýšené malé ozubení má spodní převisy: může potřebovat lokální podpory **na těle modelu**, pouze podpory z podložky nemusejí stačit |
| Kruhové čepy a zadní osa | Naležato, s podporami spodních oblouků. U čepu s větší hlavou může dřík ležet celý nad podložkou a vyžadovat podporu po délce; po očištění musí zůstat kruhový a rovný |
| Těhlice, čelisti a držáky | Zachovat exportovanou orientaci; zkontrolovat osičky, vystouplá ramena, kapsy a vodorovné otvory. Nevydáváme je za bezpodporový tisk |
| Plošina | Horní plochou na podložku, nohy nahoru; u dvou zadních nohou je 2mm boční převis, který vyžaduje kontrolu lokální podpory. Zkontrolovat také příčné otvory v nohách |
| Rám | Dnem na podložku; zkontrolovat vodorovné otvory a místní převisy kolem vidlic, motoru a serva |
| Pojistky, táhla, podložky, objímka páčky | Zachovat export; zejména drážky víka objímky, malé pojistky a jejich oddělení od podpor vyžadují prohlídku vrstev |

Rozmístění samotných modelů ani jejich rezervy pro brim nedokazují prostor pro libovolné podpory. Před tiskem je potřeba prohlédnout skutečně vygenerované dráhy, případně zvětšit mezery. Podklady neobsahují G-code ani předvolbu podpor; dosah podpor, vytlačená šířka čáry a doba tisku nebyly ověřené.

## Navazující elektronika a směr

Aktuální zapojení a potvrzený stav ovládání jsou v [elektronice autíčka](../../elektronika/auticko/README.md), vlastněné součástky v [inventáři](../../elektronika/vybaveni.md). Tato mechanická revize nemění program ani zapojení. **Tři vnější záběry obrátí směr výstupu vůči motoru**, jinak než dvoustupňováV2; při první fyzické zkoušce ověř směr s koly nad podložkou. Jakékoli přepojování dělat bez napájení.

## Kusovník

<!-- BOM-BEGIN -->
**Kusovník: 34 různých typů, celkem 66 fyzických kusů.** Počty jsou odvozené ze skutečných montážních instancí uložené sestavy. Kompletní ZIP obsahuje každou kopii zvlášť; tabulka není pokyn k dalšímu násobení součástí ve sliceru.

| Typ STL | Počet | Místo v sestavě |
|---|---:|---|
| [mezikolo-a-54_18](stl/mezikolo-a-54_18.stl) |1 |U motoru; velké 54 a malé 18 zubů |
| [mezikolo-b-60_22](stl/mezikolo-b-60_22.stl) |1 |U zadní osy; velké 60 a malé 22 zubů |
| [vystupni-kolo-55](stl/vystupni-kolo-55.stl) |1 |Na zadní ose, zajištěné příčným klínkem |
| [pastorek-18-otvor-2_2](stl/pastorek-18-otvor-2_2.stl) |1 |Nový pastorek motoru; fit 2,2 znovu ověřit |
| [ram-25](stl/ram-25.stl) |1 |Společný rám s uložením pohonu i řízení |
| [pevny-cep-8x53_9](stl/pevny-cep-8x53_9.stl) |2 |Po jednom do každého mezikola |
| [pojistka-6_9](stl/pojistka-6_9.stl) |7 |2 pevné čepy +2 svislé čepy +2 přední kola +1 kloub páčky |
| [pricny-klinek-4x27_1](stl/pricny-klinek-4x27_1.stl) |1 |Spoj výstupního kola a zadní osy |
| [pojistka-3_1](stl/pojistka-3_1.stl) |10 |1 klínek osy +2 motor +4 plošina +2 servo +1 objímka páčky |
| [spolecny-cep-mustku-4x30_5](stl/spolecny-cep-mustku-4x30_5.stl) |2 |Dva dlouhé čepy pro oba motorové můstky |
| [cep-plosiny-4x19_5](stl/cep-plosiny-4x19_5.stl) |4 |Po jednom do každé nohy plošiny |
| [pojistka-osy-10_9](stl/pojistka-osy-10_9.stl) |4 |2 vnitřní zajištění zadní osy +2 zadní kola |
| [osa-zadni-12x150_6](stl/osa-zadni-12x150_6.stl) |1 |Kruhové pracovní plochy, D konce pro zadní kola |
| [rozperka-zadni-17_6](stl/rozperka-zadni-17_6.stl) |2 |Jedna na každé straně zadní osy |
| [kolo-76x12-zadni-d](stl/kolo-76x12-zadni-d.stl) |2 |Dvě poháněná zadní kola s D otvorem |
| [kolo-76x12-predni](stl/kolo-76x12-predni.stl) |2 |Dvě volně otočná přední kola |
| [motorovy-mustek](stl/motorovy-mustek.stl) |2 |Dva horní motorové třmeny |
| [motorovy-klinek](stl/motorovy-klinek.stl) |2 |Po jednom přítlačném klínku do každého můstku |
| [plosina-170x60](stl/plosina-170x60.stl) |1 |Plošina s užitnou plochou 170 × 60 |
| [servo-viko](stl/servo-viko.stl) |1 |Zachycení původních uší SG90 |
| [servo-cep-4x51_2](stl/servo-cep-4x51_2.stl) |2 |Dva čepy víka serva |
| [objimka-packy-spodek](stl/objimka-packy-spodek.stl) |1 |Spodní tvarové zachycení originální páčky |
| [objimka-packy-viko](stl/objimka-packy-viko.stl) |1 |Zasouvací víko s vlastním otočným čepem |
| [objimka-cep-4x25_5](stl/objimka-cep-4x25_5.stl) |1 |Zajištění spodku a víka objímky |
| [podlozka-packy-1_8](stl/podlozka-packy-1_8.stl) |1 |Distanční podložka pod oko servotáhla |
| [celist-horni](stl/celist-horni.stl) |2 |Jedna horní vidlice na každé straně řízení |
| [svisly-cep-8](stl/svisly-cep-8.stl) |2 |Dva svislé čepy řízení |
| [tehlice-leva](stl/tehlice-leva.stl) |1 |Levá otočná těhlice s osičkou předního kola |
| [tehlice-prava](stl/tehlice-prava.stl) |1 |Pravá otočná těhlice s osičkou předního kola |
| [spojovaci-tahlo](stl/spojovaci-tahlo.stl) |1 |Propojení obou ramen řízení, odsazení dopředu |
| [servo-tahlo-r15](stl/servo-tahlo-r15.stl) |1 |Propojení originální páčky s levým ramenem |
| [cep-tahla-dlouhy](stl/cep-tahla-dlouhy.stl) |1 |Levý kloub s oběma táhly |
| [cep-tahla-kratky](stl/cep-tahla-kratky.stl) |1 |Pravý kloub spojovacího táhla |
| [pojistka-kloubu-4_9](stl/pojistka-kloubu-4_9.stl) |2 |Po jedné pod každý kloub táhla |

**Přesně čtyři kola:** dvě přední a dvě zadní. Mezi opakované díly patří také všechny rozpěrky, podložky, čepy a pojistky. Původní motor, servo, jeho jednoramenná páčka a středový šroubek jsou referenční vlastněné součásti, netisknou se a nejsou v 66 kusech.
<!-- BOM-END -->

## Zásady první montáže

Postupuje se po jednotlivých uloženích a záběrech s odpojeným motorovým napájením. Nejdříve musí jít lehce otočit samotné osy; pak postupně přidávat stupně a pokaždé zkusit celou otáčku, teprve nakonec motor. Při tvrdém místě převod nepřemáhat motorem. Pracovní kluzné plochy a zuby neslepovat; olej nemá napravovat geometrickou kolizi. Zkouška před tiskem není nahrazena CAD kontrolou.

[Montážní návod](montaz.md) rozlišuje zadní rozpěrky, klínek, zajištění motoru a přední řízení. Levý společný motorový čep je nutné osadit před mezikolem A; později mu mezikolo překáží v přímé montážní dráze.

## Dokončené kontroly a jejich rozsah

[Souhrnný záznam CAD](kontrola-modelu.json) má `validation_pass=true` až po spojení kontrol převodu, řízení, vůlí, parametrických vazeb a GUI. Obsahuje hashe všech čtyř zdrojů generátoru.

- 2346 párů nominální sestavy bez objemových kolizí; skutečné rotační obálky ozubení proti okolním dílům.
- 65 vzorků fáze všech tří záběrů při nominální i nejmenší rozteči bez průniku. Analytický kontaktní poměr při největší rozteči je nejméně **1,20401**. Skutečná nejtenčí špička 18zubých kol má tětivu **0,558857 mm**; nejde o důkaz pevnosti ani vyplnění tryskou 0,4 mm.
- Všech 16 kombinací krajních axiálních poloh soukolí: celý poslední 8mm pastorek zůstává uvnitř 12mm věnce, rezerva nejméně **1,4 mm**. První záběr má při nejhorší vůli šířku **4,9 mm**, ne vždy celých 5 mm.
- Řízení v 21 polohách včetně ±25° a ±27°, plné rotační obálky předních kol, zachycení dorazy při ±27,5°. Samostatně 1340 kontrol krajních axiálních poloh předních kol a 24 zadních.
- Pět parametrických zkoušek pohonu a tři řízení s návratem geometrie; algebraická kinematika v 5401 polohách. Nejde o zatěžovací výpočet serva.
- Uložení a opětovné otevření FCStd v GUI, nulová poloha řízení, pět skutečných náhledů. [Rozložený pohled](rozlozena-sestava.png) zobrazuje všech 66 dílů; není simulací montážních drah ani tiskovou podložkou.
- [Nezávislá kontrola](nezavisla-kontrola.json): 9450 kontrol v devíti polohách řízení a 110 kontrol obálek rotorů, včetně světových transformací vnořených sestav.
- [Kontrola exportů](overeni-exportu.json): shoda instancí, kusovníku, uzavřených STL a kopií ZIP; [zachování původních souborů a kalibrace](overeni-zachovani.json).
- [Kontrola úplnosti všech tří 3MF](rozlozeni/overeni-kusovniku.json) a [importu do Anycubic Slicer Next](rozlozeni/overeni-importu.json): 26 + 27 + 13 = 66 kusů při měřítku 1:1, zachované tiskové orientace a původní trojúhelníky. Okraje nejméně 6 mm, mezery půdorysných obálek nejméně 11,02 mm. To je prostor pro uvažovaný brim 5 mm s odstupem 0,1 mm, nikoli potvrzení dosahu skutečných podpor. G-code ani vrstvy nebyly generované.

Kontroly pracují s tuhými návrhovými tělesy a vybranými polohami. Nepokrývají pružné deformace, naklopení z tiskových nepřesností, teplo, opotřebení ani skutečné zatížení. Fyzický fit SG90 a objímky páčky, tisknutelnost podpor, pevnost, přilnavost a životnost zůstávají neověřené. Žádný G-code nebyl vytvořen; tiskárna, motor ani servo nebyly ovládány.
